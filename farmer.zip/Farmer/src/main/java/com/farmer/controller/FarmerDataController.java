package com.farmer.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.farmer.module.FarmerData;
import com.farmer.repository.CropDetailsRepository;
import com.farmer.repository.FarmerDataRepository;

@RestController
public class FarmerDataController {
	
	
	@Autowired
	private FarmerDataRepository farmerDataRepository;
	
	@Autowired
	private CropDetailsRepository cropDetailsrepository;
	
	
	@GetMapping("/findallfarmer")
	public List<FarmerData>getFarmerAllData(){
		
		return farmerDataRepository.findAll();
	}
	
	@PostMapping("/savefarmerdata")
	public String addFarmerData(@RequestBody  FarmerData farmerData) {
		farmerDataRepository.save(farmerData);
		return "Successfully Add Farmer Data ";
		
	}
	

	@GetMapping("/findallfarmer/{id}")
	public Optional<FarmerData> getSellerById(@PathVariable("id") int id){
		return farmerDataRepository.findById(id);
	}
	
	@DeleteMapping("/delete/{id}")
	public String DeletefarmerDatebyId(@PathVariable ("id") int id ) {
		farmerDataRepository.deleteById(id);
		return "Delete Farmer Data Successfully";
		
	}
	
	
	

}
